from sagemaker.session import Session
from sagemaker.experiments.run import Run, load_run
from sagemaker.utils import unique_name_from_base
import os
import sys
import logging
#from IPython.display import set_matplotlib_formats
from matplotlib import pyplot as plt
import numpy as np

import gymnasium
import jax
import coax
import haiku as hk
import jax.numpy as jnp
from numpy import prod
import optax
import time

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler(sys.stdout))

import shutup;
shutup.please()

# the name of this script
name = 'sac'

env = gymnasium.make('MGM-v0')
env = coax.wrappers.TrainMonitor(env, name=name, tensorboard_dir=f"./data/tensorboard/{name}")

#hyperparmeters
layer_size=8
n_layer=3
buffer_size=25000
alpha=0.2
batch=128
maxT=450000

def func_pi(S, is_training):
    a='hk.Linear(layer_size), jax.nn.relu, '
    n=0
    input='hk.Sequential(( '
    while n<n_layer:
        input+=a
        n+=1
    input+='hk.Linear(prod(env.action_space.shape) * 2, w_init=jnp.zeros), hk.Reshape((*env.action_space.shape, 2)), ))'
    seq=eval(input)

    x = seq(S)
    mu, logvar = x[..., 0], x[..., 1]
    return {'mu': mu, 'logvar': logvar}


def func_q(S, A, is_training):
    a='hk.Linear(layer_size), jax.nn.relu, '
    n=0
    input='hk.Sequential(( '
    while n<n_layer:
        input+=a
        n+=1
    input+='hk.Linear(1, w_init=jnp.zeros), jnp.ravel ))'
    seq=eval(input)

    X = jnp.concatenate((S, A), axis=-1)
    return seq(X)
    

def train(time0, total_reward, pi, q1, q2, q1_targ, q2_targ, tracer, buffer, policy_regularizer, qlearning1, qlearning2, soft_pg):
    s, info = env.reset()
    for t in range(env.spec.max_episode_steps):
        a = pi(s)
        s_next, r, done, truncated, info = env.step(a)
        total_reward+=r
        # trace rewards and add transition to replay buffer
        tracer.add(s, a, r, done)
        while tracer:
            buffer.add(tracer.pop())

        # learn
        if len(buffer) >= 5000:
            transition_batch = buffer.sample(batch_size=128)

            # init metrics dict
            metrics = {}

            # flip a coin to decide which of the q-functions to update
            qlearning = qlearning1 if jax.random.bernoulli(q1.rng) else qlearning2
            metrics.update(qlearning.update(transition_batch))

            # delayed policy updates
            if env.T >= 7500 and env.T % 4 == 0:
                metrics.update(soft_pg.update(transition_batch))

            env.record_metrics(metrics)

            # sync target networks
            q1_targ.soft_update(q1, tau=0.001)
            q2_targ.soft_update(q2, tau=0.001)

        if done or truncated:
            break
        
        s = s_next
        # run.log_metric(name="Iteration", value=env.T)
        # run.log_metric(name="Timestep", value=t)
        # run.log_metric(name="X", value=s[0])
        # run.log_metric(name="Y", value=s[1])
        # run.log_metric(name="Thetadot", value=s[2])
    #print(total_reward)
    #if total_reward/200. >-0.5:  break    
    #run.log_metric(name="ProcessTime", value= time.process_time()-time0)
    #run.log_metric(name="TotalReward", value=total_reward)
    #run.log_metric(name="Reward", value=total_reward/200)

    #tracker.append([time.time(), total_reward])

if __name__ == "__main__":
    
    time0=time.process_time()
    total_reward=0.
    
    # main function approximators
    pi = coax.Policy(func_pi, env)
    q1 = coax.Q(func_q, env, action_preprocessor=pi.proba_dist.preprocess_variate)
    q2 = coax.Q(func_q, env, action_preprocessor=pi.proba_dist.preprocess_variate)

    # target network
    q1_targ = q1.copy()
    q2_targ = q2.copy()

    # experience tracer
    tracer = coax.reward_tracing.NStep(n=5, gamma=0.9, record_extra_info=True)
    buffer = coax.experience_replay.SimpleReplayBuffer(capacity=buffer_size)

    policy_regularizer = coax.regularizers.NStepEntropyRegularizer(pi,
                                                                   beta=alpha / tracer.n,
                                                                   gamma=tracer.gamma,
                                                                   n=[tracer.n])

    # updaters (use current pi to update the q-functions and use sampled action in contrast to TD3)
    qlearning1 = coax.td_learning.SoftClippedDoubleQLearning(
        q1, pi_targ_list=[pi], q_targ_list=[q1_targ, q2_targ],
        loss_function=coax.value_losses.mse, optimizer=optax.adam(1e-3),
        policy_regularizer=policy_regularizer)
    qlearning2 = coax.td_learning.SoftClippedDoubleQLearning(
        q2, pi_targ_list=[pi], q_targ_list=[q1_targ, q2_targ],
        loss_function=coax.value_losses.mse, optimizer=optax.adam(1e-3),
        policy_regularizer=policy_regularizer)
    soft_pg = coax.policy_objectives.SoftPG(pi, [q1_targ, q2_targ], optimizer=optax.adam(
        1e-3), regularizer=coax.regularizers.NStepEntropyRegularizer(pi,
                                                                     beta=alpha / tracer.n,
                                                                     gamma=tracer.gamma,
                                                                     n=jnp.arange(tracer.n)))
                                                                     
     
     
    
    # train
    #t=0
    while env.T < maxT:
        train(time0, total_reward, pi, q1, q2, q1_targ, q2_targ, tracer, buffer, policy_regularizer, qlearning1, qlearning2, soft_pg)
        #t+=1