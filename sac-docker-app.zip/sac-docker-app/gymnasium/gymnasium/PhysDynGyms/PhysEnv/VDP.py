#taken from https://www.gymlibrary.dev/content/environment_creation/
#create gym for van der pol oscillator
#action space: continuous  +/- 1.0 float , maybe make scale to mu 
#observation space:  -10,10 x2 float for x and y
#reward:  -1*(x^2+y^2)^1/2 (try to drive to 0)

#van der pol equations:
#xdot = y; ydot = mu(1-x^2)y-x
#for this gymnasium, assume mu constant at 1, and ydot=ydot+b, where b is action

from os import path
from typing import Optional

import numpy as np

import gymnasium as gym
from gymnasium import spaces
from gymnasium.envs.classic_control import utils
from gymnasium.error import DependencyNotInstalled


class VDPEnv(gym.Env):
    #no render modes
    def __init__(self, render_mode=None, size=10):
        self.size=size
        self.window_size=1024
        
        self.observation_space =spaces.Dict(
            {
                "x": spaces.Box(-size+1, size-1, shape=(2,), dtype=float),
            }
        )
        
        self.action_space = spaces.Box(-5, 5, shape=(1,), dtype=float) 
        #need to update action to normal distribution
        
        assert render_mode is None or render_mode in self.metadata["render_modes"]
        self.render_mode=render_mode
        
        self.window= None
        self.clock = None
        
    def _get_obs(self):
        return {"x": self._x_location}

    def _get_info(self):
        #return np.linalg.norm(self._agent_location - self._target_location, ord=1)
        #obsolete/unused for gymslotin6.3
        return{"distance": np.linalg.norm(self._agent_location - self._target_location, ord=1)}

    def reset(self, options=None):
        #need below to seed self.np_random
        super().reset(seed=seed)

        #start random x1, x2 origin
        x=np.random.uniform(-8.,8.)
        while (x>-0.2 and x<0.2):
            x=np.random.uniform(-8.,8.)
        y=np.random.uniform(-8.,8.)
        while (y>-0.2 and y<0.2):
            y=np.random.uniform(-8.,8.)
        self._x_location = np.array([x,y])#  self.np_random.uniform(0, 1, size=2, dtype=float)
        observation = self._get_obs()

        if self.render_mode =="human":
            self._render_frame()

        return observation
    
    def step(self,action):
        hit=0
        bang=0
        u=action#need to update action to normal distribution
        x1=0.001*(self._x_location[1])#dt=0.001
        x2=0.001*((1-self._x_location[0]**2)*self._x_location[1]+action+self._x_location[0])
        self._x_location=np.array([np.asscalar(x1),np.asscalar(x2)])
        #punish for banging into wall
        done=False
        observation=self._get_obs()
        info=x1
        done=(abs(x1)<0.01)# and action<0.5) 
        if done:
            reward = 5000.0
            hit=1
        else:
            reward = 1/(abs(x1))#-action
        if (max(observation["x"])>10 or min(observation["x"])<-10):#avoid walls
            reward=-500.0
            done=True
            bang=1
            #print("bang")
        observation = self._get_obs()
        info = x1

        return observation, reward, done, info, hit, bang
    
    def close(self):
        if self.window is not None:
            pygame.display.quit()
            pygame.quit()
            
register(
    id='VDP-v0',
    entry_point='PhysEnv.VDP:VDPEnv'
)