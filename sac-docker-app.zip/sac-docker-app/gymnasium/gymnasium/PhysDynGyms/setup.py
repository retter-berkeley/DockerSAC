from setuptools import setup

setup(
    name='PhysEnv',
    version='0.0.1',
    keywords='games, environment, agent, rl, ai, gym',
    description='Phys Env',
    packages=['PhysEnv'],
    install_requires=[
        'gymnasium',
        'numpy',
    ]
)